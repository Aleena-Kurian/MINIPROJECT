<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Cake</title>

    <!-- swiper link  -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- cdn icon link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- custom css file  -->
	<link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="style2.css">

</head>

<body>
<!-- header section start here  -->
    <header class="header">
        <div class="logoContent">
            <a href="#" class="logo">
            <img src="img/logo.png" alt=""></a>
            <h1 class="logoName">Cake Boutique</h1>
        </div>
 
        <nav class="navbar">
            <a href="#home">Home</a>
            <a href="login.php">Sign up/login</a>
            <a href="#review">About</a>
            <a href="#contact">Contact</a>
            <a href="#"><img src="images/cart.png" alt=""></a>
        </nav>
 
        <div class="icon">
            <i class="fas fa-search" id="search"></i>
            <i class="fas fa-bars" id="menu-bar"></i>
        </div>
 
        <div class="search">
            <input type="search" placeholder="search...">
        </div>
    </header>
    <!-- header section end here  -->
 
    <!-- home section start here  -->
    <section class="home" id="home">
        <div class="homeContent">
            <h2>Order Your Cake </h2>
            <h2>Make Your Day Special </h2>
            <p>Celebrate The Day With Us</p>
            <div class="home-btn">
                <a href="#"><button>see more</button></a>
            </div>
        </div>
    </section>
 
    <!-- home section end here  -->
 
    <!-- product section start here  -->
<section class="product" id="product">
        <div class="heading">
            <h2>Our Exclusive Products</h2>
        </div>
        <div class="swiper product-row">
            <div class="swiper-wrapper">
               <div class="swiper-slide box">
                    <div class="img">
                        <img src="img/chocolate.png" alt="">
                    </div>
                    <div class="product-content">
                        <p>Chocolate Truffle Delicious Cake </br>0.5 kg  ₹450
                        </p>
                        <div class="orderNow">
                            <button onclick="window.location.href = '#';">Order Now </button>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <div class="img">
                        <img src="img/pineapple.png" alt="">
                    </div>
                    <div class="product-content">
                        <p>Pineapple Cake</br>0.5 kg  ₹500
                        </p>
                        <div class="orderNow">
                            <button onclick="window.location.href = '#';">Order Now </button>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <div class="img">
                        <img src="img/choco-oreos.png" alt="">
                    </div>
                    <div class="product-content">
                        <p>choco-oreos cake</br>0.5 kg  ₹550
                        </p>
                        <div class="orderNow">
                            <button>Order Now </button>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <div class="img">
                        <img src="img/floral-vanilla-cream-cake.png" alt="">
                    </div>
                    <div class="product-content">
                        <p>floral-vanilla-cream-cake</br>0.5 kg  ₹600
                        </p>
                        <div class="orderNow">
                            <button>Order Now </button>
                        </div>
                    </div>
                </div>
                                                       <div class="swiper-slide box">
                    <div class="img">
                        <img src="img/floral-vanilla-cream-cake.png" alt="">
                    </div>
                    <div class="product-content">
                        <p>floral-vanilla-cream-cake</br>0.5 kg  ₹600
                        </p>
                        <div class="orderNow">
                            <button>Order Now </button>
                        </div>
                    </div>
                </div>
 
            </div>
            <div class="swiper-pagination"></div>
        </div>
        
                                                       
 
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>

	
 
    
</body>

</html>
