<!DOCTYPE html>
<html>
<head>
	<title>login sign up</title>
	<link rel="stylesheet" type="text/css" href="loginstyle.css">
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet"> 
</head>
<body>
	<div class="main">  	
		<input type="checkbox" id="chk" aria-hidden="true">

			<div class="signup">
				<form name="signup" action="connection.php" method="POST">
					<label for="chk" aria-hidden="true">Sign up</label>
					<input type="email" name="email" id="name"placeholder="Email" required="">
					<input type="password" name="pswd" id="pswd" placeholder="Password" required="">
					<input type="password" name="txt" id="confpaswd" placeholder="Confirm Password" required="">
					<button name="submit" onclick="verifyPassword">Sign up</button>
				</form>
			</div>

			<div class="login">
				<form name="login" action="loginconnection.php" method="post">
					<label for="chk" aria-hidden="true">Login</label>
					<input type="email" name="email" placeholder="Email" required="">
					<input type="password" name="pswd" placeholder="Password" required="">
					<br>
					<button name="submit">Login</button>
				</form>
			</div>
	</div>
</body>
</html>