 
<script>
         function verify_firstname() 
         {  
 
            //firstname validation
            var correct_way=/^[A-Za-z]/;
            var fname=document.myform.firstname.value;
            if(fname.match(correct_way))
            {
                document.getElementById("message").innerHTML = "   "; 
                return true;
            }
            else
            {
                
                 document.getElementById("message").innerHTML = "****First Name field can only contain characters";  
                return false;  
             }  
      
 
            //lastname validation
            var correct_way=/^[A-Za-z]/;
             var lname=document.myform.lastname.value;
             if(lname.match(correct_way))
            {
                document.getElementById("lmessage").innerHTML = "   "; 
                return true;
            }
            else
            {
                
                document.getElementById("lmessage").innerHTML = "****Last Name field can only contain characters";  
                return false;  
             }  
      
         }
      
       
        
    </script>
 
 
Sent from Mail for Windows
 
