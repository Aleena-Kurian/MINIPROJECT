<!DOCTYPE html>
<html>
<head>
<title>Insert Page page</title>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "miniproject";
// Create connection
$conn =new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " .$conn->connect_error);
}
else {
	echo"connected";
}
if($_SERVER['REQUEST_METHOD']==="POST") {
	//insertion
	if(isset($_POST['submit'])){
		if(!empty($_POST['email'])&& !empty($_POST['pswd'])){    
     $email = $_POST['email'];
     $password = $_POST['pswd'];
     $sql = "INSERT INTO customer(EMAIL,PASSWORD)
     VALUES ('$email','$password')";
     if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
		}
	}
     $conn->close();
}
?>   
</body> 
</html>